let total = 0;
let superbowl_tickets = 4500;
let laptop = 1200;
let tesla = 35000;
let camera = 1000;

total = superbowl_tickets + laptop + tesla + camera;
console.log("All the things I want will cost me: " + total);