//part1
let first_name='Kuiye';
let last_name='Du';
console.log(first_name+' '+last_name);

//part2
let rent=900;
let phone_bill=30;
let internet=45;
alert(rent);

//part3
let pass=true;
let school=null;
console.log(pass)
console.log(school)