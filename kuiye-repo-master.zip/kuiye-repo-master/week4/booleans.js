let isMarried = false;
let isAdult = true;
let isSenior = false;
let isDog = false;
let isDay = true;
let isNight = false;

console.log("isMarried: " + isMarried);
console.log("isAdult: " + isAdult);
console.log("isSenior: " + isSenior);
console.log("isDog: " + isDog);
console.log("isDay: " + isDay);
console.log("isNight: " + isNight);
