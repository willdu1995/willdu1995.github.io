// 1a: Select the <h1> element
let header = document.getElementsByTagName('h1')[0];
// 1b: Set the text of the <h1> element
header.textContent = "Let's practice DOM!"
// 1c: Set the color of the <h1> to a different color
header.style.color = '#9003ce';


// 2a: Select the '.desc' paragraph
let descNode = document.getElementsByClassName('desc')[0];
// 2b: Set the content of the '.desc' paragraph
descNode.innerHTML = "<strong>These are my hobbies:</strong>";
// The content should include at least one *HTML* tag

// 3a: Select the <ul> element
let ulNode = document.getElementsByTagName('ul')[0];
// 3b: Set the class of the <ul> to 'list'
ulNode.className = 'list';
console.log(ulNode);


// 4a: Create a new list <li> item
let liNode = document.createElement('li');
// 4b: Add content to your new list item that includes HTML
liNode.innerHTML = "<i><input> write in italics</i>";
// 4C: Append this new item to the <ul> element
ulNode.appendChild(liNode);



// 5a: Select all <input> elements
let inputNode = document.getElementsByTagName('input');
// 5b: Change all <input> elements: give them a background color of #DAF7A6
for(let i = 0; i < inputNode.length; i++){
    inputNode[i].style.backgroundColor = '#DAF7A6';
  }
// Hint: Loop


// 7a: Create a <button> element
let buttonChild = document.createElement('button');
// 7b: Set its text to 'Delete'
buttonChild.textContent = 'Delete';
// 7c: Select the '#button' <div>
let buttonParent = document.getElementById('button');
// 7d: Add the <button> inside the '#button' <div>
buttonParent.appendChild(buttonChild);


// 8a: Select the '.container' <div> (because its the '.extra' parent)
let container = document.getElementsByClassName('container')[0];
// 8b: Remove the '.extra' <div> element from the its parent
container.removeChild(document.getElementsByClassName('extra')[0]);