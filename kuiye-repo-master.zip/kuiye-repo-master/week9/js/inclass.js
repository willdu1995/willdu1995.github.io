// 1. Select the element with '#header' id, save it to a variable, and console.log that variable
let header = document.getElementById('header');
console.log(header);
// 2. Select the element with '.message' class, save it to a variable, and console.log that variable
let message = document.getElementsByClassName('message')[0];
console.log(message);
// 3. Select all elements <li> elements, save it to a variable, loop through all the <li> items and console.log them
let animal = document.getElementsByTagName('li');
for(let i = 0; i < animal.length; i++){
    console.log(animal[i]);
  }
// 5. Change the text content of the '#header' element you selected
header.textContent = "This works!";
// 6. Change the text color of the '.message' element you selected and set it to #900C3F
message.style.color= "#900C3F";


// 7. Create a new <li> with the HTML '<strong>Rhino</strong>' and add it to the <ul> element
// To do this:
// Create the new <li> element and save it to variable
let liNode = document.createElement('li');
// Set its innerHTML to '<strong>Rhino</strong>'
liNode.innerHTML = "<strong>Rhino</strong>";
// Select the <ul> element and use the appendChild method to append your new <li>
let parentNode = document.getElementById('list');
parentNode.appendChild(liNode);
// Note: look at the message.js file as reference.
