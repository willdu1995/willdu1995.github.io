let buttonNode = document.querySelector('button');
let divNode = document.querySelector('div');
let pNode = document.querySelector('p');
divNode.style.display = 'none';
function displayClock(){
    buttonNode.style.display = 'none';
    divNode.style.display = 'block';
    setTimeout(function () {

        function showTime() {
            divNode.style.display = 'none';
            let dateTime = new Date();
            let time = dateTime.toLocaleTimeString();
            pNode.textContent = time;
          }
          let display = setInterval(showTime, 1000);
          
    }, 5000);
}
buttonNode.addEventListener('click',displayClock);