let phone = {
    brand: 'apple',
    model: 'iPhone 7',
    year: '2016',
    phone_number: '617-888-8888',
    operating_system: 'iOS 14.1',
    isUpdated: true,
    isStorageFull: true,
    sendToVoiceMail: function(){
        alert('Thank you for calling, I will return your call as soon as possible.');
    },
    makeCall: function(){
        let call = prompt('Enter call number','');
        let i = call.length;
        alert('Calling phone number: '+ call[0]+call[1]+call[2]+'-'+call[3]+call[4]+call[5]+'-'+call[6]+call[7]+call[8]+call[9]);
    }
};
//1.
console.log(phone);
//2.
phone.model = 'iPhone 12',
phone.year = '2020',
phone.isStorageFull = false;
//3.
console.log(phone);
//4.
phone.sendToVoiceMail();
//5.
phone.makeCall();