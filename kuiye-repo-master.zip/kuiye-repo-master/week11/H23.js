let xhr = new XMLHttpRequest();
xhr.onreadystatechange = function () {
  if (xhr.readyState === 4) {
    console.log(xhr.responseText);
    console.log(typeof xhr.responseText);
    let course = JSON.parse(xhr.responseText);
    console.log(course);
    console.log(typeof course);
let ul_1 = document.getElementsByTagName('ul')[0];
let ul_2 = document.getElementsByTagName('ul')[1];
let ul_3 = document.getElementsByTagName('ul')[2];
let name1 = document.createElement('li');
let num1 = document.createElement('li');
let prof1 = document.createElement('li');
let loc1 = document.createElement('li');
ul_1.appendChild(name1);
ul_1.appendChild(num1);
ul_1.appendChild(prof1);
ul_1.appendChild(loc1);
let name2 = document.createElement('li');
let num2 = document.createElement('li');
let prof2 = document.createElement('li');
let loc2 = document.createElement('li');
ul_2.appendChild(name2);
ul_2.appendChild(num2);
ul_2.appendChild(prof2);
ul_2.appendChild(loc2);
let name3 = document.createElement('li');
let num3 = document.createElement('li');
let prof3 = document.createElement('li');
let loc3 = document.createElement('li');
ul_3.appendChild(name3);
ul_3.appendChild(num3);
ul_3.appendChild(prof3);
ul_3.appendChild(loc3);
    for (let i=0; i < course.length; i++){
        console.log(course[i].courseName);
        console.log(course[i].courseNumber);
        console.log(course[i].professorName);
        console.log(course[i].location);
    name1.textContent = course[0].courseName;
    name2.textContent = course[1].courseName;
    name3.textContent = course[2].courseName;
    num1.textContent = course[0].courseNumber;
    num2.textContent = course[1].courseNumber;
    num3.textContent = course[2].courseNumber;
    prof1.textContent = course[0].professorName;
    prof2.textContent = course[1].professorName;
    prof3.textContent = course[2].professorName;
    loc1.textContent = course[0].location;
    loc2.textContent = course[1].location;    
    loc3.textContent = course[2].location;
    }
  }
};
xhr.open('GET', 'courses.json');
xhr.send();
