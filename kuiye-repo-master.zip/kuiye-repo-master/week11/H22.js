//Create an HTML file that contains a form with one input field and a submit button.
//Make sure that the form's default behavior is prevented.
let formNode = document.getElementsByTagName('form')[0];
//Capture the text entered by the user in the input field.
let inputNode = formNode.querySelector('input');
console.log(formNode);
console.log(inputNode);
formNode.addEventListener('submit', function (event) {
  event.preventDefault();
//Console log the type of data entered in the text field.
  console.log(inputNode.value);
  let input = inputNode.value;
  console.log('input is type ' + typeof input);
//Attempt to convert the data into a Number data type and 
//console log the result using Number() or parseInt()
  let isNumber = Number(input);
  console.log(isNumber);
  console.log('isNumber is type ' + typeof isNumber);
//Display the input field value in yellow banner below the form.
  let divNode = document.getElementsByTagName('div')[0];
  let aNode = document.createElement('a');
  aNode.textContent = input+' ';
  divNode.appendChild(aNode);
  inputNode.value = '';
});