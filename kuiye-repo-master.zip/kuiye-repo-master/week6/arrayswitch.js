//Problem 1
let seasons = ['Spring','Summer','Fall','Winter'];
let answer1 = prompt ("What's the current season?(Capitalize initial)", "");
for (let i=0; i < seasons.length; i++) {
    if (answer1 == seasons[i])
    alert ('Congratulations!  '+seasons[i]+' is here.');
    console.log (seasons[i]);
}
//Problem 2
let answer2 = prompt ("What's the current month?(Capitalize initial)", "");
switch (answer2){
    case 'January':
    case 'February':
    case 'March':
        console.log("Winter");
        break;
    case 'April':
    case 'May':
    case 'June':
        console.log("Spring");
        break;
    case 'July':
    case 'August':
    case 'September':
        console.log("Summer");
        break;
    case 'October':
    case 'November':
    case 'December':
        console.log("Winter");
    default:(alert('Please check your spelling.'));
}
//Problem 3
let answer3 = prompt ("What's the current month?(Capitalize initial)", "");

if (answer3 == "January"||answer3 =="February"||answer3 =="March")
    console.log("Winter");
    else if (answer3 == "April"||answer3 =="May"||answer3 =="June") 
    console.log("Spring");
    else if (answer3 == "July"||answer3 =="August"||answer3 =="September") 
    console.log("Summer");
    else if (answer3 == "October"||answer3 =="November"||answer3 =="December") 
    console.log("Winter");
    else (alert('Please check your spelling.'));
//Problem 4
let age = Number(prompt("What's your age?",''));
if (age >= 0 && age<= 20)
alert ("You're under age!")

 