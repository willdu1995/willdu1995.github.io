//Problem 1
function age_indays(age){
    return age*365;
}
alert('My age is '+ age_indays(25) + ' in days.');
//Problem 2
function monthly_bill(gas,electric,cable,internet,phone){
let total=0.97*(gas+electric+cable+internet+phone)
return "Your total monthly bill amount is "+ total+ ".";
}
alert(monthly_bill(0,16,0,25,30));