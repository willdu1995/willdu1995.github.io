//Part 1
let carbrands = ['Ford','Toyota','BMW','Audi','Honda','Tesla'];
console.log (carbrands); 

carbrands.push ('Nissan','Mercedes','Volkswagen');
console.log (carbrands); 

carbrands.shift ();
console.log (carbrands); 

//Part 2
let fre = prompt('Enter a frequency (choose from 1000, 2000, 3000 or 4000)', '');
switch (fre) {
    case '1000' :
        console.log ('alpha');
        break;
    case '2000' :
        console.log ('beta');
        break;
    case '3000' :
        console.log ('gamma');
        break;
    case '4000' :
        console.log ('delta');
        break;
}