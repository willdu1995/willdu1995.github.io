//Part A establish the function
function Calculator(num1, num2, operation){
    if (operation == "+"){
        return num1+num2;
    } else if (operation == "-"){
        return num1-num2;
    } else if (operation == "*"){
        return num1*num2;
    } else if (operation == "/" && num2 != 0){
        return num1/num2;
    }
}
//Part B
alert ("Welcome to your calculator, enter your numbers and operator separately.")
let num1 = null;
let num2 = null;
let operation = null;
let UserNo = null;// I need to assign a boolean value to set the condition for while loop
while (UserNo != "no"){
num1 = Number(prompt("Enter your first number", ""));
num2 = Number(prompt("Enter your second number", ""));
operation = prompt("Choose your operation: '+' to add; '-' to substract; '*' to multiply; '/' to divide", "");
alert("The result total of your calculation is " + Calculator(num1,num2,operation));
UserNo = prompt ("Would you want to perform another calculation?", "");
}
