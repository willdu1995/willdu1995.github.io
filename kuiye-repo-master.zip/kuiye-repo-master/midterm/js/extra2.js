let input = null;
while (input != "exit") {
    input = prompt("Type in something and I will encode it for you.(Enter 'exit' to stop.)","");
    if (input != "exit"){
    for (let i = input.length - 1; i > -1; i = i-1){
        if (input[i] == "a"){
            document.write ("1");
        } else if (input[i] == "e"){
            document.write ("2");
        } else if (input[i] == "i"){
            document.write ("3");
        } else if (input[i] == "o"){
            document.write ("4");
        } else if (input[i] == "u"){
            document.write ("5");
        } else
        document.write (input[i]+" ");
    }
    }
}