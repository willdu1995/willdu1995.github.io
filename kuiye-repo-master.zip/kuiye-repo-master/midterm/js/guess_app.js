let true_num = 88;
let guess = null; //I have to define guess before the loop and have the promt in the loop. So guess = null for now. 
//when true_num = guess, the player guessed the right number and while loop exits 
while (guess != true_num){
    guess = Number(prompt("Guess a integer between 1 and 100.",""));
    if (guess < true_num && guess >= 1){
        alert('Guess higher!');
        } else if (guess > true_num && guess <= 100){
        alert('Guess lower!');    
        } else if (guess == true_num) {
        alert("Yes!! You've won the game!")
        } else {
        alert('Please follow the instructions!');
        }
}