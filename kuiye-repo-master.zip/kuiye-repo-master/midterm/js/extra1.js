let input = null;
while (input != "exit") {
    input = prompt("Type in something and I will reverse it for you.(Enter 'exit' to stop.)","");
    if (input != "exit"){
    for (let i = input.length - 1; i > -1; i = i-1){
        document.write (input[i]+" ");
    }
    }
}