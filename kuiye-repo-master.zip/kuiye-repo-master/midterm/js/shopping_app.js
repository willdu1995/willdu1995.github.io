let shoppingList = [];
let input = null;
alert ("Welcome to your shopping list!");
alert ("Instructions: 'delete' to delete your first item; 'show' to display each item; 'exit' to leave the app.");
while (input != "exit"){
        input = prompt ("Please enter your item or instruction.","");
if (input == "delete") {
        shoppingList.shift();
} else if (input == "show"){
    for (let i = 0; i< shoppingList.length; i ++) {
    alert("Your current item is: "+ shoppingList[i]);
    }
} 
else (shoppingList.push(input));
}
//"exit" shows up at the end of the list; I haven't found a way around the loop so I delete it right after exiting the loop
shoppingList.pop ();
console.log(shoppingList);