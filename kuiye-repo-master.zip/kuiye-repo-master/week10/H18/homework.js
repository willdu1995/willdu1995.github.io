// select the body element and
let bodyNode = document.getElementsByTagName("body")[0];
// change its style property so that there is a 10px marginLeft
bodyNode.style.marginLeft = '10px';

// select all div elements and
let divNode = document.getElementsByTagName('div');
// change the backgroundColor to the second and fourth divs to #c70039
divNode[1].style.backgroundColor = '#c70039';
divNode[3].style.backgroundColor = '#c70039';
// and change the (font) color of the first, third and fifth to #ff9700
divNode[0].style.color = '#ff9700';
divNode[2].style.color = '#ff9700';
divNode[4].style.color = '#ff9700';
//
// select all <h2>s and
let h2Node = document.getElementsByTagName('h2');
// change the first <h2> style so that the fontWeight is bold and fontSize is 15px
h2Node[0].style.fontWeight = 'bold';
h2Node[0].style.fontSize = '15px';
//
// select all <a> elements and
let aNode = document.getElementsByTagName('a');
// change their style property so that display = "block"
// and textDecoration = "none"
for(let i = 0; i < aNode.length; i++){
    aNode[i].style.display = 'block';
    aNode[i].style.textDecoration = 'none';
  }
//
// select the element with id = "desktop",
let parentNode = document.getElementById('desktop');
// create a new <p> element with the innerHTML = "<strong>Booooo</strong>" and
let childNode = document.createElement('p');
childNode.innerHTML = "<strong>Booooo</strong>";
// append the new <p> element to the element with id = "desktop"
parentNode.appendChild(childNode);
//
// select the element with id = "taskbar" and
let delNode = document.getElementById('taskbar');
// delete it from the DOM
delNode.remove();
//
// select all elements with class = "openWindow" and delete the first one
let owNode = document.getElementsByClassName("openWindow");
owNode[0].remove();
//
// select element with id="movie",
let movieNode = document.getElementById('movie');
// create a new <h1> element with textContent = "Monsters Inc."
let monsterNode = document.createElement('h1');
movieNode.textContent = "Monsters Inc.";
// and sytle it with fontWeight="bold" and fontSize="24px"
monsterNode.style.fontWeight="bold";
monsterNode.style.fontSize="24px";
// append the new <h1> to the element with id="movie"
movieNode.appendChild(monsterNode);
