function displayDate() {
    document.getElementById("demo").innerHTML = Date();
}
let btn = document.getElementById('1');
console.log(btn);

btn.onclick = displayDate;

btn.addEventListener('click',displayDate);