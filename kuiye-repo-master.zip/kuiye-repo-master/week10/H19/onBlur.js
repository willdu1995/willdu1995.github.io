let input = document.getElementById("fname");
function makeUpperCase() {
    let x = document.getElementById("fname");
    x.value = x.value.toUpperCase();
    console.log(x);
}
input.onblur = makeUpperCase;

console.log(input)
console.log(makeUpperCase);

input.addEventListener('blur',makeUpperCase);