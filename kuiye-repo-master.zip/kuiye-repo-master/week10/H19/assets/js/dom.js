// select <a>
// select <h2>
// delete <a> from <h2>
let aH2Node = document.getElementsByTagName('a');
let h2Node = document.getElementsByTagName('h2');
console.log(aH2Node);
console.log(h2Node);
h2Node[0].removeChild(aH2Node[0]);

// create new li node
// add domColor1 as class to new li node
// add new text to li node
let liNode = document.createElement('li');
liNode.className = "domColor1";
liNode.style.opacity = '0.9';
liNode.textContent = "Hi there!";
console.log(liNode);

// select <nav>
let navNode = document.getElementsByTagName('nav');
console.log(navNode);
// append new li node to <nav> node
navNode[0].appendChild(liNode);
//navNode.appendChild(liNode);  <-- this does not work because we are working with an array/collection


// select <h1>
// add class domColor2
let h1Node = document.getElementsByTagName('h1');
h1Node[0].className = "domColor2";

// select first <a> with "btn" class
// change text content of first <a> with "btn" class
let aBtnNode = document.getElementsByClassName('btn')[0];
aBtnNode.innerHTML = "The DOM Is The <em>Bomb!</em>";


// change the text of "Some of our work" to "DOM Photo Gallery"
let h3Node = document.getElementsByClassName('title')[0];
h3Node.textContent = "DOM Photo Gallery";


// add two new <li>s the first <ul> with class "grid"
let newNode1 = document.createElement('li');
let newNode2 = document.createElement('li');
let ulNode = document.getElementsByClassName('grid')[0];
ulNode.appendChild(newNode1);
ulNode.appendChild(newNode2);
console.log(ulNode);
// fist <li>: <li class="small" style="background-image: url(assets/img/climbing1.jpg);"></li>
newNode1.className = "small";
newNode1.style.backgroundImage = "url(assets/img/climbing1.jpg)";
// second <li>: <li class="large" style="background-image: url(assets/img/climbing2.jpg);"></li>
newNode2.className = "large";
newNode2.style.backgroundImage = "url(assets/img/climbing2.jpg)";


// change the background color of the <section> with class "features"
let featureNode = document.getElementsByClassName('features')[0];
featureNode.style.backgroundColor = 'grey';
console.log(featureNode);
// add a  new <li> to <footer>'s <ul>
let newNode3 = document.createElement('li');
let footerNode = document.getElementsByTagName('ul')[2];
footerNode.appendChild(newNode3);
// The new <li> inner HTML will be: <a href="#"><i class="fa fa-github-square"></i></a>
newNode3.innerHTML = '<a href="#"><i class="fa fa-github-square"></i></a>';
console.log(newNode3);

// add a DOM event handler to the <a> with id = "subscribe"
let sub = document.getElementById("subscribe");
function showMessage(){
    divNode.style.display = "block";
}
sub.onclick = showMessage;
// create a new <div> with the message '<strong>Thank you for subscribing</strong>'
let divNode = document.createElement('div');
divNode.innerHTML ='<strong>Thank you for subscribing</strong>';
// and make the color red
divNode.style.color = 'red';
// append it to the <form> element
let formNode = document.getElementsByTagName('form')[0];
formNode.appendChild(divNode);
divNode.style.display = "none";
console.log(formNode);
