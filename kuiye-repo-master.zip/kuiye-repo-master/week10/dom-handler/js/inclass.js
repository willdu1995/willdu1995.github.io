// Select the <h1> element and change the text to uppercase, hint: use a CSS property
let h1Node=document.getElementById('header');
h1Node.textContent = h1Node.textContent.toUpperCase();
// Select the <h2> element and change the text color to  #C70039 and make it all lower case
let h2Node=document.getElementsByTagName('h2')[0];
h2Node.style.color = "#C70039";
h2Node.textContent = h2Node.textContent.toLowerCase();
// Change the background color of the page to  #58d68d when the user clicks the button on the page
let btn = document.getElementById('btn');
let body = document.getElementsByTagName('body')[0];
function changeBackground(){
    body.style.backgroundColor = "#58d68d";
}
btn.onclick = changeBackground;
// Use DOM property event handlers not HTML attribute handlers