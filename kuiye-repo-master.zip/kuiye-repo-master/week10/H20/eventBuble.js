//Part 1
let aElem = document.getElementsByTagName('a')[0];
aElem.addEventListener('click', function(event){
    event.preventDefault();
});

//Part 2
let body = document.getElementsByTagName('td');
for (let i = 0; i < body.length; i++) {
    body[i].addEventListener('click', function(){
        body[i].style.backgroundColor = "#c70039";
    });
}