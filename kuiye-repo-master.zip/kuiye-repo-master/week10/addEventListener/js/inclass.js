// Change the background color of the page to  #58d68d when the user clicks the button on the page
let btn = document.getElementById('btn');
let body = document.getElementsByTagName('body')[0];
function changeBackground(){
    body.style.backgroundColor = "#58d68d";
}
btn.addEventListener('click',changeBackground);
