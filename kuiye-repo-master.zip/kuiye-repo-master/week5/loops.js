//Part 1
let total = 0;
for (let i = 1; i <=10; i++) {
    total = i * 9;
    alert("9 times " + i + " = " + total);
}

//Part 2
let whatNumber = prompt("Give me a number between 1 and 10");
total = 0;
for (let i = 1; i <=10; i++) {
    total = i * whatNumber;
    alert(whatNumber + " times " + i + " = " + total);
}

//Part 3
let number;
total = 0;
while (number != 0) {
    number = Number(prompt('Add all the numbers up! (enter 0 to exit)'));
    total = total + number;
    alert("running total: " + total);
}

alert("Final Total Amount: " + total);

