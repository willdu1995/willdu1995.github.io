//part1
let year = prompt('What is the year today?', '');

if (year == "2020") { 
    console.log( 'Fantastic, you live in the present' );
}

//part2
let i = 10;
while (i <= 20) {
  console.log( i );
  i++;
}