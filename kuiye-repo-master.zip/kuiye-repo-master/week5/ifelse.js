let answer = prompt('Will the Patriots win the Superbowl next year?', '');

if (answer == "yes"||answer == "Yes"||answer == "YES") 
    alert( 'You are awesome!' );
    else if (answer == "no"||answer == "No"||answer =="NO") 
      alert("Get out of my house. Now!")
      else alert ("You know nothing Jon Snow")
    

